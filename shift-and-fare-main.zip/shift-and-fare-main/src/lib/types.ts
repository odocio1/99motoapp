// Type definitions

export interface User {
  id: string;
  username: string;
  password?: string;
}

export interface Ride {
  id: string;
  userId: string;
  date: string;
  time: string;
  fare: number;
  distanceKm: number;
  note: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  userId: string;
  date: string;
  time: string;
  type: "gasoline" | "maintenance" | "other";
  amount: number;
  litersOrQty: number | null;
  note: string;
  createdAt: string;
}

export interface Shift {
  id: string;
  userId: string;
  date: string;
  startTime: string;
  endTime: string | null;
  initialKm: number;
  finalKm: number | null;
  createdAt: string;
}

export interface ForumMessage {
  id: string;
  userId: string;
  username: string;
  text: string;
  createdAt: string;
}

export interface DaySummary {
  date: string;
  totalRevenue: number;
  totalExpenses: number;
  totalKm: number;
  rides: Ride[];
  expenses: Expense[];
}
