// LocalStorage utilities for data persistence

export const STORAGE_KEYS = {
  USERS: "99m_users",
  SESSION: "99m_session",
  RIDES: "99m_rides",
  EXPENSES: "99m_expenses",
  SHIFTS: "99m_shifts",
  FORUM: "99m_forum",
};

export function uid(prefix = "id"): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}

export function read<T>(key: string, fallback: T): T {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : fallback;
  } catch (e) {
    return fallback;
  }
}

export function write<T>(key: string, val: T): void {
  localStorage.setItem(key, JSON.stringify(val));
}
