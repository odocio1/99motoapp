import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { User, Ride, Expense, Shift, ForumMessage, DaySummary } from "@/lib/types";
import { STORAGE_KEYS, read, write, uid } from "@/lib/storage";

interface AppContextType {
  user: User | null;
  rides: Ride[];
  expenses: Expense[];
  shifts: Shift[];
  forum: ForumMessage[];
  login: (username: string, password: string) => { ok: boolean; message?: string };
  register: (username: string, password: string) => { ok: boolean; message?: string };
  logout: () => void;
  addRide: (data: Omit<Ride, "id" | "userId" | "createdAt">) => void;
  addExpense: (data: Omit<Expense, "id" | "userId" | "createdAt">) => void;
  startShift: (data: Omit<Shift, "id" | "userId" | "endTime" | "finalKm" | "createdAt">) => void;
  endShift: (shiftId: string, data: { endTime: string; finalKm: number }) => void;
  postForum: (text: string) => void;
  getUserRides: () => Ride[];
  getUserExpenses: () => Expense[];
  getUserShifts: () => Shift[];
  getDaySummaries: () => DaySummary[];
  getTotals: () => { totalRevenue: number; totalExpenses: number; totalKm: number; profit: number };
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => read(STORAGE_KEYS.SESSION, null));
  const [rides, setRides] = useState<Ride[]>(() => read(STORAGE_KEYS.RIDES, []));
  const [expenses, setExpenses] = useState<Expense[]>(() => read(STORAGE_KEYS.EXPENSES, []));
  const [shifts, setShifts] = useState<Shift[]>(() => read(STORAGE_KEYS.SHIFTS, []));
  const [forum, setForum] = useState<ForumMessage[]>(() => read(STORAGE_KEYS.FORUM, []));

  useEffect(() => write(STORAGE_KEYS.SESSION, user), [user]);
  useEffect(() => write(STORAGE_KEYS.RIDES, rides), [rides]);
  useEffect(() => write(STORAGE_KEYS.EXPENSES, expenses), [expenses]);
  useEffect(() => write(STORAGE_KEYS.SHIFTS, shifts), [shifts]);
  useEffect(() => write(STORAGE_KEYS.FORUM, forum), [forum]);

  const register = (username: string, password: string) => {
    const users = read<User[]>(STORAGE_KEYS.USERS, []);
    if (users.find((u) => u.username === username)) {
      return { ok: false, message: "Usuário já existe" };
    }
    const newUser = { id: uid("u"), username, password };
    users.push(newUser);
    write(STORAGE_KEYS.USERS, users);
    setUser({ id: newUser.id, username: newUser.username });
    return { ok: true };
  };

  const login = (username: string, password: string) => {
    const users = read<User[]>(STORAGE_KEYS.USERS, []);
    const found = users.find((u) => u.username === username && u.password === password);
    if (!found) return { ok: false, message: "Usuário ou senha inválidos" };
    setUser({ id: found.id, username: found.username });
    return { ok: true };
  };

  const logout = () => setUser(null);

  const addRide = (data: Omit<Ride, "id" | "userId" | "createdAt">) => {
    if (!user) return;
    const ride: Ride = {
      ...data,
      id: uid("ride"),
      userId: user.id,
      createdAt: new Date().toISOString(),
    };
    setRides((prev) => [...prev, ride]);
  };

  const addExpense = (data: Omit<Expense, "id" | "userId" | "createdAt">) => {
    if (!user) return;
    const expense: Expense = {
      ...data,
      id: uid("exp"),
      userId: user.id,
      createdAt: new Date().toISOString(),
    };
    setExpenses((prev) => [...prev, expense]);
  };

  const startShift = (data: Omit<Shift, "id" | "userId" | "endTime" | "finalKm" | "createdAt">) => {
    if (!user) return;
    const shift: Shift = {
      ...data,
      id: uid("shift"),
      userId: user.id,
      endTime: null,
      finalKm: null,
      createdAt: new Date().toISOString(),
    };
    setShifts((prev) => [...prev, shift]);
  };

  const endShift = (shiftId: string, data: { endTime: string; finalKm: number }) => {
    setShifts((prev) => prev.map((s) => (s.id === shiftId ? { ...s, ...data } : s)));
  };

  const postForum = (text: string) => {
    if (!user) return;
    const message: ForumMessage = {
      id: uid("msg"),
      userId: user.id,
      username: user.username,
      text,
      createdAt: new Date().toISOString(),
    };
    setForum((prev) => [message, ...prev]);
  };

  const getUserRides = () => rides.filter((r) => r.userId === user?.id);
  const getUserExpenses = () => expenses.filter((e) => e.userId === user?.id);
  const getUserShifts = () => shifts.filter((s) => s.userId === user?.id);

  const getDaySummaries = (): DaySummary[] => {
    const allDates = new Set<string>();
    getUserRides().forEach((r) => allDates.add(r.date));
    getUserExpenses().forEach((e) => allDates.add(e.date));
    getUserShifts().forEach((s) => allDates.add(s.date));

    return Array.from(allDates)
      .sort()
      .reverse()
      .map((date) => {
        const dayRides = getUserRides().filter((r) => r.date === date);
        const dayExpenses = getUserExpenses().filter((e) => e.date === date);
        return {
          date,
          totalRevenue: dayRides.reduce((s, r) => s + r.fare, 0),
          totalExpenses: dayExpenses.reduce((s, e) => s + e.amount, 0),
          totalKm: dayRides.reduce((s, r) => s + r.distanceKm, 0),
          rides: dayRides,
          expenses: dayExpenses,
        };
      });
  };

  const getTotals = () => {
    const totalRevenue = getUserRides().reduce((s, r) => s + r.fare, 0);
    const totalExpenses = getUserExpenses().reduce((s, e) => s + e.amount, 0);
    const totalKm = getUserRides().reduce((s, r) => s + r.distanceKm, 0);
    return { totalRevenue, totalExpenses, totalKm, profit: totalRevenue - totalExpenses };
  };

  return (
    <AppContext.Provider
      value={{
        user,
        rides,
        expenses,
        shifts,
        forum,
        login,
        register,
        logout,
        addRide,
        addExpense,
        startShift,
        endShift,
        postForum,
        getUserRides,
        getUserExpenses,
        getUserShifts,
        getDaySummaries,
        getTotals,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
}
