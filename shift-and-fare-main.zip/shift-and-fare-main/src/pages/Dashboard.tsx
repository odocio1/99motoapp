import { useApp } from "@/contexts/AppContext";
import { StatCard } from "@/components/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, TrendingDown, Navigation } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function Dashboard() {
  const { getTotals, getDaySummaries } = useApp();
  const totals = getTotals();
  const summaries = getDaySummaries();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Dashboard</h2>
        <p className="text-muted-foreground">Acompanhe seus ganhos e despesas</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Receita Total"
          value={`R$ ${totals.totalRevenue.toFixed(2)}`}
          icon={DollarSign}
          trend="up"
        />
        <StatCard
          title="Despesas Totais"
          value={`R$ ${totals.totalExpenses.toFixed(2)}`}
          icon={TrendingDown}
          trend="down"
        />
        <StatCard
          title="Km Rodados"
          value={`${totals.totalKm.toFixed(1)} km`}
          icon={Navigation}
          trend="neutral"
        />
        <StatCard
          title="Lucro / Prejuízo"
          value={`R$ ${totals.profit.toFixed(2)}`}
          icon={TrendingUp}
          trend={totals.profit >= 0 ? "up" : "down"}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Resumo por Dia</CardTitle>
        </CardHeader>
        <CardContent>
          {summaries.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Nenhum registro encontrado</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead className="text-right">Receita</TableHead>
                    <TableHead className="text-right">Despesas</TableHead>
                    <TableHead className="text-right">Km</TableHead>
                    <TableHead className="text-right">Lucro</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {summaries.map((summary) => {
                    const profit = summary.totalRevenue - summary.totalExpenses;
                    return (
                      <TableRow key={summary.date}>
                        <TableCell className="font-medium">
                          {new Date(summary.date).toLocaleDateString("pt-BR")}
                        </TableCell>
                        <TableCell className="text-right text-accent">
                          R$ {summary.totalRevenue.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-right text-destructive">
                          R$ {summary.totalExpenses.toFixed(2)}
                        </TableCell>
                        <TableCell className="text-right">{summary.totalKm.toFixed(1)} km</TableCell>
                        <TableCell className={`text-right font-medium ${profit >= 0 ? "text-accent" : "text-destructive"}`}>
                          R$ {profit.toFixed(2)}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
