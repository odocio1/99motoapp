import { useState } from "react";
import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export default function ShiftPage() {
  const { getUserShifts, startShift, endShift } = useApp();
  const shifts = getUserShifts();
  const today = new Date().toISOString().slice(0, 10);
  const now = new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

  const [startData, setStartData] = useState({
    date: today,
    startTime: now,
    initialKm: "",
  });

  const [endData, setEndData] = useState({
    date: today,
    endTime: now,
    finalKm: "",
  });

  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    startShift({
      date: startData.date,
      startTime: startData.startTime,
      initialKm: Number(startData.initialKm),
    });
    toast.success("Plantão iniciado!");
    setStartData({ date: today, startTime: now, initialKm: "" });
  };

  const handleEnd = (e: React.FormEvent) => {
    e.preventDefault();
    const openShift = shifts
      .slice()
      .reverse()
      .find((s) => s.date === endData.date && !s.endTime);
    
    if (!openShift) {
      toast.error("Nenhum plantão aberto encontrado para este dia");
      return;
    }

    endShift(openShift.id, {
      endTime: endData.endTime,
      finalKm: Number(endData.finalKm),
    });
    toast.success("Plantão finalizado!");
    setEndData({ date: today, endTime: now, finalKm: "" });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Gerenciar Plantões</h2>
        <p className="text-muted-foreground">Registre início e fim dos seus plantões</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Iniciar Plantão</CardTitle>
            <CardDescription>Registre o início do seu dia de trabalho</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleStart} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="start-date">Data</Label>
                <Input
                  id="start-date"
                  type="date"
                  value={startData.date}
                  onChange={(e) => setStartData({ ...startData, date: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="start-time">Hora de Início</Label>
                <Input
                  id="start-time"
                  type="time"
                  value={startData.startTime}
                  onChange={(e) => setStartData({ ...startData, startTime: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="initial-km">Km Inicial</Label>
                <Input
                  id="initial-km"
                  type="number"
                  step="0.1"
                  min="0"
                  placeholder="0"
                  value={startData.initialKm}
                  onChange={(e) => setStartData({ ...startData, initialKm: e.target.value })}
                  required
                />
              </div>
              <Button type="submit" className="w-full">Iniciar Plantão</Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Finalizar Plantão</CardTitle>
            <CardDescription>Registre o fim do seu dia de trabalho</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleEnd} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="end-date">Data</Label>
                <Input
                  id="end-date"
                  type="date"
                  value={endData.date}
                  onChange={(e) => setEndData({ ...endData, date: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="end-time">Hora de Fim</Label>
                <Input
                  id="end-time"
                  type="time"
                  value={endData.endTime}
                  onChange={(e) => setEndData({ ...endData, endTime: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="final-km">Km Final</Label>
                <Input
                  id="final-km"
                  type="number"
                  step="0.1"
                  min="0"
                  placeholder="0"
                  value={endData.finalKm}
                  onChange={(e) => setEndData({ ...endData, finalKm: e.target.value })}
                  required
                />
              </div>
              <Button type="submit" variant="destructive" className="w-full">
                Finalizar Plantão
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Plantões</CardTitle>
        </CardHeader>
        <CardContent>
          {shifts.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Nenhum plantão registrado</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Início</TableHead>
                    <TableHead>Fim</TableHead>
                    <TableHead>Km Inicial</TableHead>
                    <TableHead>Km Final</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shifts.slice().reverse().map((shift) => (
                    <TableRow key={shift.id}>
                      <TableCell>{new Date(shift.date).toLocaleDateString("pt-BR")}</TableCell>
                      <TableCell>{shift.startTime}</TableCell>
                      <TableCell>{shift.endTime || "—"}</TableCell>
                      <TableCell>{shift.initialKm}</TableCell>
                      <TableCell>{shift.finalKm || "—"}</TableCell>
                      <TableCell>
                        {shift.endTime ? (
                          <Badge variant="secondary">Finalizado</Badge>
                        ) : (
                          <Badge>Em andamento</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
