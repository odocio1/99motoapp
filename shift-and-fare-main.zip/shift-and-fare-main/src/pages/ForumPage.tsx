import { useState } from "react";
import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MessageSquare } from "lucide-react";
import { toast } from "sonner";

export default function ForumPage() {
  const { forum, postForum } = useApp();
  const [text, setText] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      toast.error("Digite uma mensagem");
      return;
    }
    postForum(text);
    setText("");
    toast.success("Mensagem publicada!");
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Fórum dos Motoqueiros</h2>
        <p className="text-muted-foreground">Compartilhe dicas, perguntas e experiências</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Nova Mensagem</CardTitle>
          <CardDescription>Publique uma dúvida, dica ou comentário</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Textarea
              placeholder="Escreva sua mensagem aqui..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={4}
              required
            />
            <div className="flex justify-end">
              <Button type="submit">
                <MessageSquare className="w-4 h-4 mr-2" />
                Publicar
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {forum.length === 0 ? (
          <Card>
            <CardContent className="py-12">
              <p className="text-center text-muted-foreground">
                Nenhuma mensagem ainda. Seja o primeiro a postar!
              </p>
            </CardContent>
          </Card>
        ) : (
          forum.map((message) => (
            <Card key={message.id}>
              <CardContent className="pt-6">
                <div className="flex gap-4">
                  <Avatar>
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {message.username.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{message.username}</span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(message.createdAt).toLocaleString("pt-BR")}
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed">{message.text}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
