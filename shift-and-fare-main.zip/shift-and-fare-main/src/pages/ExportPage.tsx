import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, FileSpreadsheet } from "lucide-react";
import { toast } from "sonner";

export default function ExportPage() {
  const { getUserRides, getUserExpenses, getUserShifts, user } = useApp();

  const downloadCSV = () => {
    if (!user) return;

    const header = ["type", "date", "time", "value", "units", "note"];
    const rows: string[][] = [];

    getUserRides().forEach((r) => {
      rows.push(["ride", r.date, r.time, r.fare.toString(), r.distanceKm.toString(), r.note]);
    });

    getUserExpenses().forEach((e) => {
      rows.push([
        e.type,
        e.date,
        e.time,
        e.amount.toString(),
        e.litersOrQty?.toString() || "",
        e.note,
      ]);
    });

    getUserShifts().forEach((s) => {
      rows.push([
        "shift",
        s.date,
        `${s.startTime}-${s.endTime || ""}`,
        "",
        `${s.initialKm} -> ${s.finalKm || ""}`,
        "",
      ]);
    });

    const csv = [
      header.join(","),
      ...rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `99moto_export_${user.username}_${new Date().toISOString().slice(0, 19)}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast.success("Arquivo CSV baixado com sucesso!");
  };

  const rides = getUserRides();
  const expenses = getUserExpenses();
  const shifts = getUserShifts();
  const totalRecords = rides.length + expenses.length + shifts.length;

  return (
    <div className="max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6" />
            Exportar Dados
          </CardTitle>
          <CardDescription>
            Baixe todos os seus dados em formato CSV para análise em planilhas
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-primary/5 rounded-lg">
              <div className="text-3xl font-bold text-primary">{rides.length}</div>
              <div className="text-sm text-muted-foreground">Corridas</div>
            </div>
            <div className="text-center p-4 bg-destructive/5 rounded-lg">
              <div className="text-3xl font-bold text-destructive">{expenses.length}</div>
              <div className="text-sm text-muted-foreground">Despesas</div>
            </div>
            <div className="text-center p-4 bg-accent/5 rounded-lg">
              <div className="text-3xl font-bold text-accent">{shifts.length}</div>
              <div className="text-sm text-muted-foreground">Plantões</div>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold">O que será exportado:</h3>
            <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
              <li>Todas as corridas registradas com valores e distâncias</li>
              <li>Todas as despesas com tipos e quantidades</li>
              <li>Todos os plantões com horários e quilometragens</li>
              <li>Total de {totalRecords} registros</li>
            </ul>
          </div>

          <div className="bg-muted p-4 rounded-lg text-sm">
            <p className="font-medium mb-1">Formato CSV</p>
            <p className="text-muted-foreground">
              O arquivo pode ser aberto em Excel, Google Sheets, LibreOffice Calc e outros
              programas de planilhas.
            </p>
          </div>

          <Button onClick={downloadCSV} size="lg" className="w-full">
            <Download className="w-5 h-5 mr-2" />
            Baixar CSV
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
