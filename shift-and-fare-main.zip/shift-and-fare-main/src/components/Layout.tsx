import { ReactNode } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, Plus, DollarSign, Clock, MessageSquare, Download, LogOut } from "lucide-react";
import logo99 from "@/assets/logo-99.png";

export function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useApp();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/auth");
  };

  const navItems = [
    { path: "/", icon: LayoutDashboard, label: "Dashboard" },
    { path: "/ride", icon: Plus, label: "Nova Corrida" },
    { path: "/expense", icon: DollarSign, label: "Despesa" },
    { path: "/shift", icon: Clock, label: "Plantão" },
    { path: "/forum", icon: MessageSquare, label: "Fórum" },
    { path: "/export", icon: Download, label: "Exportar" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <header className="bg-card border-b sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-11 h-11 bg-gradient-to-br from-primary to-primary/90 rounded-xl shadow-lg hover:scale-105 transition-transform flex items-center justify-center overflow-hidden">
              <img 
                src={logo99} 
                alt="99 Logo" 
                className="w-full h-full object-cover mix-blend-multiply dark:mix-blend-screen" 
              />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">99Moto</h1>
              <p className="text-xs text-muted-foreground">Painel do motoqueiro</p>
            </div>
          </Link>
          
          {user && (
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium">{user.username}</p>
                <p className="text-xs text-muted-foreground">Piloto</p>
              </div>
              <Button onClick={handleLogout} variant="outline" size="sm">
                <LogOut className="w-4 h-4 sm:mr-2" />
                <span className="hidden sm:inline">Sair</span>
              </Button>
            </div>
          )}
        </div>
      </header>

      {user && (
        <nav className="bg-card border-b overflow-x-auto">
          <div className="container mx-auto px-4">
            <div className="flex gap-1 py-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link key={item.path} to={item.path}>
                    <Button
                      variant={isActive ? "default" : "ghost"}
                      size="sm"
                      className="gap-2 whitespace-nowrap"
                    >
                      <Icon className="w-4 h-4" />
                      <span className="hidden sm:inline">{item.label}</span>
                    </Button>
                  </Link>
                );
              })}
            </div>
          </div>
        </nav>
      )}

      <main className="container mx-auto px-4 py-6">{children}</main>

      <footer className="mt-12 py-6 text-center text-sm text-muted-foreground border-t bg-card/50">
        <p>99Moto — Dados salvos localmente no navegador</p>
      </footer>
    </div>
  );
}
